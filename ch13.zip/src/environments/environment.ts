// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false, 
  firebaseConfig: {
    apiKey: "AIzaSyD8avTDOtYAvfssRn7oTeToDcfh0vy_3UM",
    authDomain: "angularcrud-8ff16.firebaseapp.com",
    databaseURL: "https://angularcrud-8ff16.firebaseio.com",
    projectId: "angularcrud-8ff16",
    storageBucket: "angularcrud-8ff16.appspot.com",
    messagingSenderId: "535937646377",
    appId: "1:535937646377:web:bdbb1a22c799c4d3658138",
    measurementId: "G-118JW3B903"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
